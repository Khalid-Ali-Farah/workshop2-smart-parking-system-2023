package com.example.smartparkingsystem;

public class Config {

    public static final String DATA_URL = "https://PASTE_YOUR_URL?id=";

    public static final String KEY_NAME = "name";

    public static final String JSON_ARRAY = "result";
}
