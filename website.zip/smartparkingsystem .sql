-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 25, 2023 at 06:54 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smartparkingsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE `administrator` (
  `ID` char(6) NOT NULL,
  `Email` varchar(80) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`ID`, `Email`, `Password`) VALUES
('A00123', 'a@gmail.com', '123'),
('Admin_', 'k@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `backup_record`
--

CREATE TABLE `backup_record` (
  `ID` varchar(7) NOT NULL,
  `Customer_Username` varchar(50) NOT NULL,
  `Plate_Number` varchar(8) NOT NULL,
  `Starting_Date` datetime NOT NULL,
  `End_Date` datetime NOT NULL,
  `Duration` varchar(50) NOT NULL,
  `Report_ID` varchar(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `ID` varchar(10) NOT NULL,
  `Customer_Username` varchar(50) DEFAULT NULL,
  `Plate_Number` varchar(8) DEFAULT NULL,
  `Vehicle_Type` varchar(10) DEFAULT NULL,
  `Starting_Date` varchar(10) DEFAULT NULL,
  `End_Date` varchar(10) DEFAULT NULL,
  `Duration` varchar(100) NOT NULL,
  `Start_Time` varchar(10) DEFAULT NULL,
  `End_Time` varchar(10) DEFAULT NULL,
  `Station` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`ID`, `Customer_Username`, `Plate_Number`, `Vehicle_Type`, `Starting_Date`, `End_Date`, `Duration`, `Start_Time`, `End_Time`, `Station`) VALUES
('B00001', 'huda', 'JMH123', 'Small', '16/1/2023', '16/1/2023', '2 hours 0 minutes ', '01:00:pm', '03:00:pm', 'Bukit Beruang'),
('B00002', 'huda', 'JLP765', 'Small', '17/1/2023', '17/1/2023', '5 hours 0 minutes ', '11:00:am', '04:00:pm', 'Bukit Beruang'),
('B00003', 'tralala', 'JHY112', 'Small', '16/1/2023', '17/01/2023', '2 hours 0 minutes ', '07:00:pm', '00:00 am', 'Bukit Beruang'),
('B00004', 'tralala', 'WRG788', 'Large', '16/1/2023', '18/01/2023', '2 hours 0 minutes ', '08:00:pm', '04:00 am', 'Mitc Melaka'),
('B00005', 'yaya', 'HUI123', 'Small', '16/1/2023', '16/1/2023', '7 hours 23 minutes ', '02:00:pm', '09:23:pm', 'Bukit Beruang'),
('B00006', 'yaya', 'WTY678', 'Small', '16/1/2023', '16/1/2023', '10 hours 20 minutes ', '12:00:pm', '10:20:pm', 'Bukit Beruang'),
('B00007', 'intan', 'JSB678', 'Small', '17/1/2023', '17/1/2023', '3 hours 0 minutes ', '04:00:pm', '07:00:pm', 'Bukit Beruang'),
('B00008', 'intan', 'JSB678', 'Large', '18/1/2023', '18/1/2023', '6 hours 0 minutes ', '12:00:pm', '06:00:pm', 'Bukit Beruang'),
('B00009', 'fatin', 'KLA566', 'Small', '17/1/2023', '17/1/2023', '2 hours 0 minutes ', '09:00:pm', '11:00:pm', 'Bukit Beruang'),
('B00010', 'fatin', 'KLA566', 'Small', '17/1/2023', '17/1/2023', '1 hours 0 minutes ', '08:00:pm', '09:20:pm', 'Mitc Melaka');

-- --------------------------------------------------------

--
-- Table structure for table `booking_parking_lot`
--

CREATE TABLE `booking_parking_lot` (
  `Booking_ID` varchar(6) NOT NULL,
  `Parking_Station_ID` varchar(10) DEFAULT NULL,
  `Floor` int(11) DEFAULT NULL,
  `Code` char(1) DEFAULT NULL,
  `Sequence` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking_parking_lot`
--

INSERT INTO `booking_parking_lot` (`Booking_ID`, `Parking_Station_ID`, `Floor`, `Code`, `Sequence`) VALUES
('B00001', 'PS001', 1, 'A', 1),
('B00002', 'PS001', 1, 'A', 2),
('B00003', 'PS001', 1, 'A', 3),
('B00004', 'PS002', 2, 'A', 1),
('B00005', 'PS001', 1, 'A', 4),
('B00006', 'PS001', 1, 'A', 5),
('B00007', 'PS001', 1, 'A', 6),
('B00009', 'PS001', 1, 'A', 7),
('B00010', 'PS001', 1, 'A', 8);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Email` varchar(80) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Email`, `Password`, `Username`) VALUES
('fatin@gmail.com', 'fatin', 'fatin'),
('hudafirzana@gmail.com', 'huda', 'huda'),
('intan@gmail.com', 'intan', 'intan'),
('thirae', 'thirae', 'thirae'),
('tralala@gmail.com', 'tralala', 'tralala'),
('yaya@gmail.com', 'yaya', 'yaya');

-- --------------------------------------------------------

--
-- Table structure for table `customer_profile`
--

CREATE TABLE `customer_profile` (
  `ID` int(11) NOT NULL,
  `Username` varchar(50) DEFAULT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `PhoneNum` varchar(12) DEFAULT NULL,
  `ICNum` varchar(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer_profile`
--

INSERT INTO `customer_profile` (`ID`, `Username`, `FirstName`, `LastName`, `PhoneNum`, `ICNum`) VALUES
(15, 'huda', 'Firzana Huda', 'Azreel', '01162618293', '010628100998'),
(16, 'tralala', 'Tralala', 'tralala', '0192829', '1192929'),
(17, 'yaya', 'yaya', 'yaya', '010229', '1192389'),
(18, 'thirae', NULL, NULL, NULL, NULL),
(19, 'intan', 'Intan Liyana', 'Ahmad', '0136752346', '0107268965'),
(20, 'fatin', 'Fatin Hanani ', 'Azreel ', '01162618283', '010628100999');

-- --------------------------------------------------------

--
-- Table structure for table `customer_vehicle`
--

CREATE TABLE `customer_vehicle` (
  `ID` int(1) NOT NULL,
  `Customer_Username` varchar(50) DEFAULT NULL,
  `Plate_Number1` varchar(8) NOT NULL,
  `Plate_Number2` varchar(8) DEFAULT NULL,
  `Plate_Number3` varchar(8) DEFAULT NULL,
  `Plate_Number4` varchar(8) DEFAULT NULL,
  `Plate_Number5` varchar(8) DEFAULT NULL,
  `CarNum` varchar(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer_vehicle`
--

INSERT INTO `customer_vehicle` (`ID`, `Customer_Username`, `Plate_Number1`, `Plate_Number2`, `Plate_Number3`, `Plate_Number4`, `Plate_Number5`, `CarNum`) VALUES
(1, 'huda', 'JMH123', 'JLP765', '', '', '', '2'),
(4, 'tralala', 'JHY112', 'WRG788', '', '', '', '2'),
(5, 'yaya', 'HUI123', 'WTY678', '', '', '', '2'),
(6, 'thirae', '', NULL, NULL, NULL, NULL, NULL),
(7, 'intan', 'R3688', 'JSB678', '', '', '', '2'),
(8, 'fatin', 'THO987', 'KLA566', 'WER677', '', '', '3');

-- --------------------------------------------------------

--
-- Table structure for table `overtime_vehicle`
--

CREATE TABLE `overtime_vehicle` (
  `ID` varchar(5) NOT NULL,
  `Plate_Number` varchar(8) DEFAULT NULL,
  `Status` varchar(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `overtime_vehicle`
--

INSERT INTO `overtime_vehicle` (`ID`, `Plate_Number`, `Status`) VALUES
('O0001', 'KLA566', '');

-- --------------------------------------------------------

--
-- Table structure for table `parking_lot`
--

CREATE TABLE `parking_lot` (
  `ID` varchar(5) NOT NULL,
  `Parking_Station_ID` varchar(10) NOT NULL,
  `Floor` int(11) NOT NULL,
  `Code` varchar(1) NOT NULL,
  `Capacity` int(11) NOT NULL,
  `Parking_Size` varchar(10) NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parking_lot`
--

INSERT INTO `parking_lot` (`ID`, `Parking_Station_ID`, `Floor`, `Code`, `Capacity`, `Parking_Size`, `Status`) VALUES
('PL001', 'PS001', 1, 'A', 40, 'Small', 'available'),
('PL002', 'PS001', 1, 'B', 30, 'Small', 'available'),
('PL003', 'PS001', 2, 'A', 50, 'Small', 'available'),
('PL004', 'PS001', 3, 'A', 40, 'Small', 'available'),
('PL005', 'PS001', 4, 'A', 30, 'Large', 'available'),
('PL006', 'PS002', 1, 'A', 30, 'Small', 'available'),
('PL007', 'PS002', 1, 'B', 30, 'Small', 'available'),
('PL008', 'PS002', 1, 'C', 20, 'Small', 'available'),
('PL009', 'PS002', 2, 'A', 40, 'Large', 'available'),
('PL010', 'PS003', 1, 'A', 30, 'Small', 'available'),
('PL011', 'PS003', 1, 'B', 30, 'Small', 'available'),
('PL012', 'PS003', 2, 'A', 30, 'Small', 'available'),
('PL013', 'PS003', 2, 'B', 30, 'Small', 'available'),
('PL014', 'PS003', 3, 'A', 30, 'Small', 'available'),
('PL015', 'PS003', 3, 'B', 30, 'Large', 'available');

-- --------------------------------------------------------

--
-- Table structure for table `parking_station`
--

CREATE TABLE `parking_station` (
  `ID` varchar(5) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Address` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parking_station`
--

INSERT INTO `parking_station` (`ID`, `Name`, `Address`) VALUES
('PS001', 'Bukit Beruang', 'Bukit Beruang Melaka'),
('PS002', 'Mitc Melaka', 'Mitc Melaka');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `ID` int(6) NOT NULL,
  `Booking_ID` varchar(6) NOT NULL,
  `Payment_Date` varchar(20) NOT NULL,
  `Total` double(6,2) NOT NULL,
  `Status` varchar(10) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `BookingPayment` double(6,2) NOT NULL,
  `carPlate` varchar(20) NOT NULL,
  `Normal_Hour` int(4) NOT NULL,
  `Normal_Day` int(4) NOT NULL,
  `Holi_Hour` int(4) NOT NULL,
  `Holi_Day` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`ID`, `Booking_ID`, `Payment_Date`, `Total`, `Status`, `Username`, `BookingPayment`, `carPlate`, `Normal_Hour`, `Normal_Day`, `Holi_Hour`, `Holi_Day`) VALUES
(2, 'B00001', '2023-01-12 17:10:50', 0.00, 'Not Paid', '', 0.00, 'JMH123', 0, 0, 0, 0),
(3, 'B00002', '2023-01-12 17:10:50', 0.00, 'Not Paid', '', 0.00, 'JLP765', 0, 0, 0, 0),
(4, 'B00003', '2023-01-12 17:10:50', 5.00, ' Paid', '', 10.00, 'JHY112', 5, 0, 0, 0),
(5, 'B00004', '2023-01-13 17:10:50', 13.00, ' Paid', '', 5.00, 'WRG788', 8, 1, 0, 0),
(6, 'B00005', '2023-01-13 17:10:50', 0.00, 'Not Paid', '', 0.00, 'HUI123', 0, 0, 0, 0),
(7, 'B00006', '2023-01-14 17:10:50', 0.00, 'Not Paid', '', 0.00, 'WTY678', 0, 0, 0, 0),
(8, 'B00007', '2023-01-14 17:10:50', 0.00, 'Not Paid', '', 0.00, 'JSB678', 0, 0, 0, 0),
(9, 'B00008', '2023-01-15 17:10:50', 0.00, 'Not Paid', '', 0.00, 'JSB678', 0, 0, 0, 0),
(10, 'B00009', '2023-01-17 17:10:50', 0.00, 'Not Paid', '', 0.00, 'KLA566', 0, 0, 0, 0),
(11, 'B00010', '2023-01-17 17:10:50', 30.00, ' Paid', '', 0.00, 'KLA566', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `price_update`
--

CREATE TABLE `price_update` (
  `ID` char(3) NOT NULL,
  `Normal_Price_Per_Hour` int(11) DEFAULT NULL,
  `Holiday_Price_Per_Hour` int(11) DEFAULT NULL,
  `Normal_Price_Per_Day` int(11) DEFAULT NULL,
  `Holiday_Price_Per_Day` int(11) DEFAULT NULL,
  `Penalty_Price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `price_update`
--

INSERT INTO `price_update` (`ID`, `Normal_Price_Per_Hour`, `Holiday_Price_Per_Hour`, `Normal_Price_Per_Day`, `Holiday_Price_Per_Day`, `Penalty_Price`) VALUES
('UP1', 3, 5, 6, 30, 30);

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `ID` varchar(6) NOT NULL,
  `Admin_ID` varchar(6) DEFAULT NULL,
  `Report_Type` varchar(10) NOT NULL,
  `Type_Range` varchar(15) NOT NULL,
  `Total_Ticket` int(11) NOT NULL,
  `Total_Sales` double(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `scanning`
--

CREATE TABLE `scanning` (
  `ID` varchar(6) NOT NULL,
  `Booking_ID` varchar(6) DEFAULT NULL,
  `Plate_Number` varchar(8) NOT NULL,
  `QRCode` varchar(50) DEFAULT NULL,
  `Status` varchar(10) NOT NULL,
  `Username` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `scanning`
--

INSERT INTO `scanning` (`ID`, `Booking_ID`, `Plate_Number`, `QRCode`, `Status`, `Username`) VALUES
('SC001', 'B00003', 'JHY112', '', 'parked', 'tralala'),
('SC002', 'B00004', 'WRG788', '', 'parked', 'tralala'),
('SC003', 'B00010', 'KLA566', NULL, 'parked', 'fatin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrator`
--
ALTER TABLE `administrator`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `backup_record`
--
ALTER TABLE `backup_record`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `booking_parking_lot`
--
ALTER TABLE `booking_parking_lot`
  ADD PRIMARY KEY (`Booking_ID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Username`);

--
-- Indexes for table `customer_profile`
--
ALTER TABLE `customer_profile`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `customer_vehicle`
--
ALTER TABLE `customer_vehicle`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `overtime_vehicle`
--
ALTER TABLE `overtime_vehicle`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `parking_lot`
--
ALTER TABLE `parking_lot`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `parking_station`
--
ALTER TABLE `parking_station`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `price_update`
--
ALTER TABLE `price_update`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `scanning`
--
ALTER TABLE `scanning`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer_profile`
--
ALTER TABLE `customer_profile`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `customer_vehicle`
--
ALTER TABLE `customer_vehicle`
  MODIFY `ID` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `ID` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
