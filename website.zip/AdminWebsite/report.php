<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Funda of Web IT</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>
  
    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card mt-5">

                <style>
    .card-header {
      color: white;
      background-color: #61356D;
      display: flex;
      justify-content: center;
      align-items: center;
      
    }
   
  </style>
                    <div class="card-header">
                        <h4>Report Table</h4>
                    </div>
                    <div class="card-body">
                        
                        <form action="" method="GET">
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="input-group mb-3">
                                        <select name="sort_numeric" class="form-control">
                                            <option value="">--Select Option--</option>
                                            <option value="low-high" <?php if(isset($_GET['sort_numeric']) && $_GET['sort_numeric'] == "low-high") { echo "selected"; } ?> > Low - High</option>
                                            <option value="high-low" <?php if(isset($_GET['sort_numeric']) && $_GET['sort_numeric'] == "high-low") { echo "selected"; } ?> > High - Low</option>
                                        </select>
                                        <style>
                                   .btn-primary {
                                    color: white;
                                    background-color: #61356D;
                                    border: #61356D;
      
                                       }
                                       </style>
                                        <button type="submit" class="input-group-text btn btn-primary" id="basic-addon2">
                                            Filter
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>

                        <table class="table table-bordered">
                            <thead>
                                <tr>
                    <th>ID</th>
                    <th>Admin_ID</th>
                    <th>Report_Type</th>
                    <th>Type_Range</th>
                    <th>Total_Ticket</th>
                    <th>Total_Sales</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php 
                                $con = mysqli_connect("localhost","root","","smartparkingsystem");

                                $sort_option = "";
                                if(isset($_GET['sort_numeric']))
                                {
                                    if($_GET['sort_numeric'] == "low-high"){
                                        $sort_option = "ASC";
                                    }elseif($_GET['sort_numeric'] == "high-low"){
                                        $sort_option = "DESC";
                                    }
                                }
                                
                                $query = "SELECT * FROM report ORDER BY Total_Sales $sort_option";
                                $query_run = mysqli_query($con, $query);

                                if(mysqli_num_rows($query_run) > 0)
                                {
                                    foreach($query_run as $row)
                                    {
                                        ?>
                                            <tr>
                    <td><?php echo $row['ID'];?></td>
                    <td><?php echo $row['Admin_ID'];?></td>
                    <td><?php echo $row['Report_Type'];?></td>
                    <td><?php echo $row['Type_Range'];?></td>
                    <td><?php echo $row['Total_Ticket'];?></td>
                    <td><?php echo $row['Total_Sales'];?></td>
                                            </tr>
                                        <?php
                                    }
                                }
                                else
                                {
                                    ?>
                                    <tr>
                                        <td colspan="3">No Record Found</td>
                                    </tr>
                                    <?php
                                }
                            ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
</body>

<section>
  <style>
    section {
      margin-top:5px;
      display: flex;
      justify-content: center;
      align-items: center;
      
    }
   
  </style>

 <input type="button" value="Go back!" onclick="history.back()">

  </section>

</html>
