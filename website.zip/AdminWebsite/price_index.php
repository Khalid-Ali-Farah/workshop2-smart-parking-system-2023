<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Price Update Table</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Inter:wght@300&display=swap" rel="stylesheet">
<style> @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300&display=swap'); </style>
<!-- <link href="price_style.css" rel="stylesheet"> -->

  </head>
  <body>

  <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card mt-5">
                <style>
    .card-header {
      color: white;
      background-color: #61356D;
      display: flex;
      justify-content: center;
      align-items: center;
      
    }
   
  </style>
 <div class="card-header">
 <h4>Price Update Table</h4>
 </div>

<div class="modal" tabindex="-1" role="dialog" id='modal_frm'>
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Update Price</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id='frm'>
      <input type='hidden' name='action' id='action' value='Insert'>
      <input type='hidden' name='id' id='uid' value='0'>
      <div class='form-group'>

      
      <label>Normal Price (Hour)</label>
        <input type='text' name='normal_Price_Per_Hour' id='normal_Price_Per_Hour' required class='form-control'>
      </div>

      <div class='form-group'>
        <label>Holiday Price (Hour)</label>
        <input type='text' name='holiday_Price_Per_Hour' id='holiday_Price_Per_Hour' required class='form-control'>
      </div>

      <div class='form-group'>
        <label>Normal Price (Day)</label>
        <input type='text' name='normal_Price_Per_Day' id='normal_Price_Per_Day' required class='form-control'>
      </div>

      <div class='form-group'>
        <label>Holiday Price (Day)</label>
        <input type='text' name='holiday_Price_Per_Day' id='holiday_Price_Per_Day' required class='form-control'>
      </div>
     
      <div class='form-group'>
        <label>Penalty Price</label>
        <input type='text' name='penalty_Price' id='penalty_Price' required class='form-control'>
      </div>

      <style>
       .btn-primary {
         color: white;
         background-color: #61356D;
         border: #61356D;
      
          }
        </style>
      <input type='submit' value='Submit' class='btn btn-success'>
    </form>
      </div>
    </div>
  </div>
</div>
  <div class='container mt-5'>
    <table class='table table-bordered'>
    <thead>
                   <th>Normal Price (Hour)</th>
                    <th>Holiday Price (Hour)</th>
                    <th>Normal Price (Day)</th>
                    <th>Holiday Price (Day)</th>
                    <th>Penalty Price</th>
                    <th>Edit Price</th>
    </thead>
    <tbody id='tbody'>
      <?php 
        $con=mysqli_connect("localhost","root","","smartparkingsystem");
        $sql="select * from price_update where ID = 'UP1'";
        $res=$con->query($sql);
        while($row=$res->fetch_assoc()){
          echo "
            <tr uid='{$row["ID"]}'>
            <td>RM {$row["Normal_Price_Per_Hour"]}</td>
            <td>RM {$row["Holiday_Price_Per_Hour"]}</td>
            <td>RM {$row["Normal_Price_Per_Day"]}</td>
            <td>RM {$row["Holiday_Price_Per_Day"]}</td>
            <td>RM {$row["Penalty_Price"]}</td>
            <td><a href='#' class='btn btn-primary edit'>Edit Price</a></td>
            </tr>
          ";
        }
      ?>
    </tbody>
    </table>
  </div>
    <script>
      $(document).ready(function(){
        var current_row=null;
        $("#add_record").click(function(){
          $("#modal_frm").modal();
        });
        
        $("#frm").submit(function(event){
          event.preventDefault();
          $.ajax({
            url:"price_action.php",
            type:"post",
            data:$("#frm").serialize(),
            beforeSend:function(){
              $("#frm").find("input[type='submit']").val('Loading...');
            },
            success:function(res){
              if(res){
                if($("#uid").val()=="0"){
                  $("#tbody").append(res);
                }else{
                  $(current_row).html(res);
                }
              }else{
                alert("Failed Try Again");
              }
              $("#frm").find("input[type='submit']").val('Submit');
              clear_input();
              $("#modal_frm").modal('hide');
            }
          });
        });
        
        $("body").on("click",".edit",function(event){
          event.preventDefault();
          current_row=$(this).closest("tr");
          $("#modal_frm").modal();
          var id=$(this).closest("tr").attr("uid");

          $("#action").val("Update");
          $("#uid").val(id);
        
        });
        
        function clear_input(){
          $("#frm").find(".form-control").val("");
          $("#action").val("Insert");
          $("#uid").val("0");
        }
      });
    </script>
<script>
        $(document).ready(function () {

            $('.edit').on('click', function () {

                $('#modal_frm').modal('show');

                $tr = $(this).closest('tr');

                var data = $tr.children("td").map(function () {
                    return $(this).text();
                }).get();

                console.log(data);

                $('#uid').val(data[0]);
                $('#normal_Price_Per_Hour').val(data[1]);
                $('#holiday_Price_Per_Hour').val(data[2]);
                $('#normal_Price_Per_Day').val(data[3]);
                $('#holiday_Price_Per_Day').val(data[4]);
                $('#penalty_Price').val(data[4]);

            });
        });
    </script>
<section>
  <style>
    section {
      margin-top:5px;
      display: flex;
      justify-content: center;
      align-items: center;
      
    }
   
  </style>
 <input type="button" value="Go back!" onclick="history.back()">
  </section>

  </body>
</html>
