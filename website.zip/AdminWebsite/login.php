<?php 
session_start(); 
include "db_conn.php";

if (isset($_POST['ID']) && isset($_POST['Password'])) {

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

	$id = validate($_POST['ID']);
	$pass = validate($_POST['Password']);

	if (empty($id)) {
		header("Location: login_index.php?error=ID is required");
	    exit();
	}else if(empty($pass)){
        header("Location: login_index.php?error=Password is required");
	    exit();
	}else{
		$sql = "SELECT * FROM administrator WHERE ID='$id' AND password='$pass'";

		$result = mysqli_query($conn, $sql);

		if (mysqli_num_rows($result) === 1) {
			$row = mysqli_fetch_assoc($result);
            if ($row['ID'] === $id && $row['Password'] === $pass) {
            	$_SESSION['Email'] = $row['Email'];
            	$_SESSION['ID'] = $row['ID'];
            	header("Location: adminPage.php");
		        exit();
            }else{
				header("Location: login_index.php?error=Incorrect username or password");
		        exit();
			}
		}else{
			header("Location: login_index.php?error=Incorrect username or password");
	        exit();
		}
	}
	
}else{
	header("Location: login_index.php");
	exit();
}