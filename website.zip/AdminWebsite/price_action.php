<?php

  $con=mysqli_connect("localhost","root","","smartparkingsystem");
  
  $action=$_POST["action"];
    if($action=="Update"){
    $id=$_POST["id"];
	$normal_Price_Per_Hour=mysqli_real_escape_string($con,$_POST["normal_Price_Per_Hour"]);
	$holiday_Price_Per_Hour=mysqli_real_escape_string($con,$_POST["holiday_Price_Per_Hour"]);
	$normal_Price_Per_Day=mysqli_real_escape_string($con,$_POST["normal_Price_Per_Day"]);
	$holiday_Price_Per_Day=mysqli_real_escape_string($con,$_POST["holiday_Price_Per_Day"]);
	$penalty_Price=mysqli_real_escape_string($con,$_POST["penalty_Price"]);
    $sql="update price_update set normal_Price_Per_Hour='{$normal_Price_Per_Hour}',holiday_Price_Per_Hour='{$holiday_Price_Per_Hour}',normal_Price_Per_Day='{$normal_Price_Per_Day}',holiday_Price_Per_Day='{$holiday_Price_Per_Day}',penalty_Price='{$penalty_Price}' where id='UP1'";
    if($con->query($sql)){
      echo "
      <td>RM {$normal_Price_Per_Hour}</td>
      <td>RM {$holiday_Price_Per_Hour}</td>
      <td>RM {$normal_Price_Per_Day}</td>
      <td>RM {$holiday_Price_Per_Day}</td>
      <td>RM {$penalty_Price}</td>
        <td><a href='#' class='btn btn-primary edit'>Edit</a></td>";
        
    }else{
      echo false;
    }

  }
?>
