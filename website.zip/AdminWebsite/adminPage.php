<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" type= "text/css" href="adminDashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

</head>
<body>

    <header class="header">
        
        <a href=""><i class="fa fa-fw fa-user"></i>Admin Dashboard</a>
        <div class="logout">
            <a href="login.php" class="btn btn-primary">Logout</a>
        </div>
</header>
<aside>
 <nav> 
<ul>

<li>
    <a href="price_index.php" ><i class="fa fa-fw fa-money"></i> Price Update</a>
    

</li>

<li>
    <a href="history_review.php" ><i class="fa fa-fw fa-history"></i>History review</a>

</li>

<li>
    <a href="report.php" ><i class="fa fa-fw fa-table"></i>Report</a>

</li>

</ul>
</nav> 

</aside>

<div class="content"> 
<h1> Smart Parking System</h1>



</div>


















</body>
</html>